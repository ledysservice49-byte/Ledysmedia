// Adapte la configuration du projet Expo généré automatiquement (nom, icône, lecteur vidéo, flux http).
const fs = require('fs');
const p = 'app/app.json';
const j = JSON.parse(fs.readFileSync(p, 'utf8'));
const e = (j.expo = j.expo || {});
e.name = 'Ledys Média';
e.slug = 'ledysmedia';
e.version = '1.0.0';
e.orientation = 'default';
e.userInterfaceStyle = 'dark';
e.icon = './assets/icon.png';
e.splash = { image: './assets/splash.png', resizeMode: 'contain', backgroundColor: '#000000' };
e.android = { ...(e.android || {}), package: 'com.ledysmedia.app', adaptiveIcon: { foregroundImage: './assets/adaptive-icon.png', backgroundColor: '#000000' } };
e.ios = { ...(e.ios || {}), bundleIdentifier: 'com.ledysmedia.app', supportsTablet: true };
e.plugins = [
  ...(e.plugins || []),
  ['expo-video', { supportsPictureInPicture: true }],
  ['expo-build-properties', { android: { usesCleartextTraffic: true } }],
];
fs.writeFileSync(p, JSON.stringify(j, null, 2));
console.log('app.json mis à jour');
