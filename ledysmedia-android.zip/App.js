// Ledys Média — application Android / iOS avec lecteur vidéo NATIF intégré
// (ExoPlayer sur Android = le moteur de YouTube ; AVPlayer sur iPhone). Plus de lecteur web.
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  View, Text, TextInput, FlatList, Pressable, Image, Modal, ActivityIndicator,
  ScrollView, Alert, BackHandler, Linking, Share, StyleSheet, useWindowDimensions,
} from 'react-native';
import { useVideoPlayer, VideoView } from 'expo-video';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import * as Crypto from 'expo-crypto';
import { activateKeepAwakeAsync, deactivateKeepAwake } from 'expo-keep-awake';
import AsyncStorage from '@react-native-async-storage/async-storage';

/* ============================== RÉGLAGES ============================== */
// true pour la version Google Play : retire la catégorie adulte et le paiement externe (règles de Google).
const STORE_BUILD = false;
const CONTACT_EMAIL = 'ledysservice49@gmail.com';
const DEV_NAME = 'Ir Lebon Lubo';
const PAY_URL = 'https://pay.prezpay.com/open?token=7qKZjFE8zr8W7tqJ4Zcn3f5bTVU8a456rPz33o6RILdquoLF&intent=pay';
const TRIAL_DAYS = 3, SUB_DAYS = 30, DAY = 864e5;
const SALT = 'ledysmedia-v1';
const HASHES = [
  '156e042a3f95c609893bfc37417f58a8d23c3c220a70de7939dfa4350f09f5ac',
  '874506728d9bdf751037b05aa6ddb592357cfd70e25367e33d83fce978341f40',
  '6461ba7fe12e9cbc8a66092e4a8e32a39b1a6298b5dca456db6b8aec08f9952b',
  '42f0b4eda7a6ecec9947197332a425c774649b79129a51327936499c1aed6e53',
  '807248b87cc450ac9f46b5a49eb1a96417d7b168585c115771afd7a97f9307bd',
  'e570db1f95b7e05fc51ec53c0fcd309d68ebafc2c61796b40b25564eb520cb31',
  'e3fb4b61c29ea854a3502417f5b8d79196d2f2f429105464f952473c779fbd0b',
  '4f51d4b69aac37a312307e0788916a079f5542da48b6e00e72c331da630ea260',
  '1f3f9768f7153e27a30e651da18620b9a258e41374ab2c8c0b0ab713be69ea2b',
  '162a21873a64823fbe8e2a8587fba68d3f6b365f5fbc8dc32f5d630cbf573740',
  '9aa6010d4eed1aa80ee29b7abcf8ce8965d8cdc2f7e525351835c82de542d7d9',
  '97f192e28f6f01b3d528f47150e41766479b5ed68f71488a0ea2fb87fd2abb41',
  '1b506a54e6cf364bac08e5b01fdab7b4e66243b7e165a7df8541adf0e2a26f3c',
  'c637b68662bd0c0bf279297dacb66b5fa816ebdc468a6760d6960ceca14b9428',
  '30f6edbd64ab028d772e21d9b08717707c3b544d69336422e3e02f3014e49c71',
  'd3671cf944b845b549844270df3e0b731eac5734a339560f8f81a1882d889ff1',
  '07d9fccfdcc070bf6eb94aaec48925b2dfda942f8ea4dc9112229ba85ffa1fe9',
  'f6f0ba4aa92ca830106570f5a6d256177321c76122186a43d5b3b092b06dadd9',
  '9fa5c6da550a60a963cdbec7e98d5ae99891db02515c6e468112f85f3a7afe9b',
  'c7ff7d1388422e4db337a854c99fd1c7fef1980f3c5e05f62814264f5ce117c4',
  '9283102b8f604b03241f8de58e202ba6ede850befc4a424648ef69cb10390689',
  '95ac24e96d39113d29041edfcac2aee68a2fa0c3f2012dfb39abc72124a3a21a',
  '439cdf09ca9c0127b848da7cbb1d2eafd03180ebc3683c450961359987407aa7',
  'a2f010286777384297bd9d07f19ffdc4fb282c1faab4c0cdd9e5b8d6c359f909',
  'd6f84a742e1f6a1f2b7239f321900506212d4be793261984f6e806bef6b04c13',
  'e05fe280e5ccd77ca5bad3c590a6f5287895f2328a8e4458dd540fb503f46355',
  '4950709630ebf7d3195253e5610d9a82a57b5a912e58e4e3c2ac831ce2285318',
  '03a623121cdecb9e96872688e89ec6bcc3cec7a76c3ae4ac6639dbc489360954',
  '570dc2f1b67c565205263855349c8bbe954552fdd0c8cecc236b3d26964daf1e',
  'ce812d5c8318627e5e16eb6d602c2d14e89966e701f6473cacfdd70acb354051',
  'dda44fda5a9c4275533fc6ae22284ebb033adb3e95a1d09aac0b32f68ec19108',
  'ca1990dfda1add7977f3544f5323be3abfc751cc182d3f69237613b614a0f12c',
  '582182bc64bf9054f4a07e4456c0e4196d6f27655c0319dcec0d818e3031e472',
  'eae5dee98cf9094a1992e8d19b3fd9e6d2e06eb9a0c2b6003c77fa1e433547c7',
  '16f896d6290b40f41bd687b12ec3dedf1e5beadd9eef14cce277777ae0584bd1',
  '631fae89759ed00658e38b365d3f0bbc0146be4178f41a5c2d60fe6acb1efc93',
  '7148e4f8f7b475c7b6d29b69ff71dee1933fdb842038b1f0f398c7330b5e0032',
  'd3becf713be9337d97a4db1f1850f08c18f70dc0d728db7117884289ae0bde69',
  '447cdd0e42cd1653b5e3af0b4c4b2f9a11c0f8042bec8c72f1a1390381a8af6b',
  'cb4ec8255d1dc90302065dec397c4c974bfe259a9947a0bec92c7e5a5fd53b26',
  '12b4f72805c047b782eef23cc0a54a49e54827f4025db2cb3f660b41a7509d68',
  'a1aafa4fce0aa10188133cdeca7e9f8780b90b037fe1ca92e08622548367b2cd',
  '614dd5a19d80e1ef50529bf3ab905b0672863448dce3e9f7fae179d4b21c3e92',
  '522ee89eb85e76d9ec757ac9fdaf00eba38c40b02332b6a211977525757b8f1b',
  'b03626538339aa8904cce33a4b2f5551201fad542c6b29e0d2e3d8e464811da4',
  '4d51f27d9ca523e6f2a25c65e4ff552a8ce1bdcd4b608f00ddc4c3fe96287821',
  'd20533966dce47d412a6297f30f372528b3476ef34cb6b2b973312553c6f849c',
  '66f7a65d8a0e03068499fb4d6d531c0f5cbe0a4a63c17bf9163df92ccb1dacee',
  'bf4406d36b633cf18ebfb80e3bcfa5a0bdb4c71a1a964e2b611de05b5dc30fc4',
  'ca8a826201f3194b313ccca7e92ee693b4d969ea61f14f4676feb8c9aba23066',
  'd7507b087f8e2d065e9c5a0dc18aa87d00e08b65d70c594218993a455b68ecd5',
  '8bcfac35d65556b768d6fa9b303a605a9fb3ef0250d910575c14923a0bfb1fc8',
  '07629baae293d511d72a8d70ce197210831aea414e76ced1701e48482b6e468e',
  'd5eebe5c1f759a84137b04c67496c2847423ded610e17dfc8483daa25aef7318',
  'bd0312bfb2ecda282cf74abfeb03b5de43d7ed92810c32ca6ce987d757a363ba',
  '2a89d21400ae77cd19709f32f4ea4dd1d79b71203ecb153f4cf7ae7de805433b',
  'b57928cd3b1467b18080b1fd3344520ed4c46f2cd2964efea81bf5def9cd4a47',
  '578757ecdc558516d7b97daa8fdc163864ef776b168018bbe405c28daef110a6',
  'f889b3e816f624434085b793b46a45034c79ed8413a6f7ce2bf2ae64011ec896',
  '302c341435bbef77ed028f2651f2e9c6178774cb36787df3a3fecb69a1acee60',
  '9b7e2b8a148393e3e4978d6b0d8670c99dd7b9b90bdb69e65628722bcfa5c702',
  '41a0efdf6ff6498f007558978e89238b7342e60ade159edfabbd0c7dd79dc7d2',
  'cc2852ecee4c829ed3c13e2849d0fa413e709f563f3a39269ebe5293ecbed1ad',
  'c7f917537688d486890181ea8a1a5d4779964ec8dd46d4fc78a05c0f44e39da9',
  'cce67a58ead5c3c4ec9e6cef8ef38529b89e64a56dee90526c217b899e740f99',
  '3e874967861791428887224255faf7e5f3db17b19e6b3373e76632a6aedbe2ab',
  'db8b8a08eeae1c026f350811d0dc7bcc1148535ff1b87273d3e251f0e9acd242',
  '4465a416495d327f0cfdef8fb751e3c254c9d7c9889360185236af3cfe3dedbc',
  '94fb28851817cc25c9a5e2a3063e73228564ff09bc99c6b75d2aa123990c4c3f',
  '2956d84aa38f623d032d2ed843b7933c975ca56092c68875cd87615398669744',
  '342af3b3144d9ec30fffe34e9059be7dd99219c505265b5f161c18f03a895c76',
  'ecc2a12f6774bd8df53d7f51823e204f4c6ca8c49bd4709e9b37069faebe2327',
  'ba1c1d742f5ec5c2b0b498bf8c82a77e41b9a5abc7aa7bd5fbabe3fb7cda34e2',
  '416a95441568f8b623ecd96ee3714d2a0b0ab58422f4955f3ae660e30d3877e1',
  '7aa476269637f4e3f1c3d8a586a1cf9aa56997f0c63b9fff0b4c983c8e9155ae',
  '822c5e63aac2aaee0a9c035be875c78e32530b5717f604139fae3041f4b3c143',
  'f2b24d80a4aeb9c73dc51cce1bbc4bbc056c1994ac065e10b7a7bc0514c43bcc',
  '7127c71ca8617e7e27a70383d57d04fd1a5c8c89194a60ed73f357fdcfd93d3f',
  '0a9f4b10c075fc96d2554ed42324fc863b57261ce74f00da800f4dfb7e34a13f',
  'b0cd47cdb70d334103bff4405fe7b39d3794f3fe8b422043767a7f49f6cb879f',
  '839d942376eb71a64fbd2fb2aef0140d58da1e20af5df41c1a3aa4a041852ade',
  '517fd349fa27fd0ed041bade9a3f0542cf70f6e0bb668994f78d8898787f01b4',
  '2a0db44842bad7e9df7ce4b029b9f3121dcccd9f036c7956e9e061503b1c260f',
  'a171c7f0ed972c8967625f6edc3b051400d2f6aeba4dde2dc4040eb3ec6696c0',
  '499ed154aef0c61a2564ba42e6d4694ee883e9b7751bc4e87ec5ed5c63d8c341',
  '6e6b5d941d5fd2a7f98ebc8255d521a29ae3aa0acf011519b7fefe16376b471c',
  'd05a501b12f3f06c5942526f8606524921c96138d04cd911281eac9895862572',
  'e7c7e19c966c12d87e085714df9527b3ceb5b6dbf00dad5dd580d8f99a882970',
  '9af95190765c330f8d1523c6919ccd9c642548d9ed8aef553bf1fd9c276a1b19',
  '7e599d7fa9d20c3668ea1e77db2a573ee9d5cff6f83f3ed9b620c87355ccee9a',
  'da60d6f79ce146282bf61da4e2d349b62a516468a191f4d281ebc528d0c6891c',
  '56ac4a1ec55845068ec7d55e558cdeb17299d5ee477db8bf878f3ef1504aa35f',
  'b27a04e51f1340bf554af01a059d43d9f2cf9250e9ca7fa0f1e6e47d759bdb07',
  '1c5bc1802cf80b681edeb7f1478a5533a713480c0d67d85bde93f30840f3a1f7',
  '22355f80ac6f1e61c3c8d105867d8ad69753e5929969686994e04e9fb97e0f56',
  '81171a2cae68d888697a115575b455c5bbb484c75f2ef88e9d5da0118eb18b0f',
  '9326e18b3796858936667563afe60941669e4355ffda6198a83f8aa8aef6a736',
  'a4b9191495ee7dae23063c891d9e0e52e1d38b52b5d199eefba27560b1af1edc',
  'b1304c51cee3eccf0fcfd8415231fef5272cdcef8538396aa372343327cd881f',
  '84b61ca3cb42bff41e741e7d406428f4d130104e2d97e1b6f14554c40f0167b8'
];

const C = { bg: '#0A1633', surface: '#12214A', line: '#1E3166', text: '#F4F6FB', dim: '#9AA7C7', accent: '#F7D618', red: '#CE1126' };
const BASE = 'https://iptv-org.github.io/iptv/';
const CATS = [
  { key: 'sports', ico: '⚽', name: 'Sports', url: BASE + 'categories/sports.m3u' },
  { key: 'series', ico: '📺', name: 'Séries', url: BASE + 'categories/series.m3u' },
  { key: 'movies', ico: '🎬', name: 'Films', url: BASE + 'categories/movies.m3u' },
  { key: 'kids', ico: '🧸', name: 'Jeunesse', url: BASE + 'categories/kids.m3u' },
  { key: 'adult', ico: '🔞', name: 'Adulte 18+', url: BASE + 'categories/xxx.m3u', adult: true },
];
const CATEGORIES = STORE_BUILD ? CATS.filter((c) => !c.adult) : CATS;
const PRESETS = [
  { name: 'RDC', ico: '🇨🇩', url: BASE + 'countries/cd.m3u' },
  { name: 'Chaînes en français', ico: '🗣️', url: BASE + 'languages/fra.m3u' },
  { name: 'Afrique', ico: '🌍', url: BASE + 'regions/afr.m3u' },
];
const FITS = ['contain', 'cover', 'fill'];
const FIT_LABELS = ['Adapté', 'Remplir', 'Étirer'];

/* ============================== OUTILS ============================== */
const load = async (k, d) => { try { const v = await AsyncStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } };
const save = (k, v) => { try { AsyncStorage.setItem(k, JSON.stringify(v)).catch(() => {}); } catch (e) {} };

function parseM3U(text) {
  const out = []; let cur = null;
  for (const raw of text.split(/\r?\n/)) {
    const l = raw.trim(); if (!l) continue;
    if (l.startsWith('#EXTINF')) {
      const attr = (k) => { const m = l.match(new RegExp(k + '="([^"]*)"')); return m ? m[1] : ''; };
      const comma = l.indexOf(',', l.lastIndexOf('"') + 1);
      const name = comma >= 0 ? l.slice(comma + 1).trim() : '';
      cur = { name: name || attr('tvg-name') || 'Sans nom', logo: attr('tvg-logo'), group: (attr('group-title') || 'Autres').split(';')[0] };
    } else if (!l.startsWith('#') && cur) { cur.url = l; out.push(cur); cur = null; }
  }
  return out;
}
async function fetchPlaylist(url) {
  const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 25000);
  try {
    const r = await fetch(url, { signal: ctrl.signal });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const list = parseM3U(await r.text());
    if (!list.length) throw new Error('vide');
    return list;
  } finally { clearTimeout(t); }
}
function fmtLeft(ms) {
  const d = Math.floor(ms / DAY), h = Math.floor((ms % DAY) / 36e5), m = Math.floor((ms % 36e5) / 6e4);
  return d > 0 ? d + ' j ' + h + ' h' : h + ' h ' + m + ' min';
}
function statusOf(lic, now) {
  if (STORE_BUILD) return { s: 'free', left: 0 };
  if (!lic) return { s: 'loading', left: 0 };
  const n = now < lic.last - 36e5 ? lic.last : now; // horloge reculée : on garde la dernière heure connue
  if (lic.until > n) return { s: 'active', left: lic.until - n };
  const end = lic.start + TRIAL_DAYS * DAY;
  if (n < end && !lic.until) return { s: 'trial', left: end - n };
  return { s: 'expired', left: 0 };
}

/* ============================== PETITS COMPOSANTS ============================== */
const Btn = ({ label, onPress, alt, style, disabled }) => (
  <Pressable onPress={onPress} disabled={disabled} style={[s.btn, alt && s.btnAlt, disabled && { opacity: 0.4 }, style]}>
    <Text style={[s.btnTxt, alt && { color: C.text }]}>{label}</Text>
  </Pressable>
);
const Chip = ({ label, on, onPress }) => (
  <Pressable onPress={onPress} style={[s.chip, on && s.chipOn]}><Text style={[s.chipTxt, on && s.chipTxtOn]}>{label}</Text></Pressable>
);
const IconBtn = ({ label, onPress, wide }) => (
  <Pressable onPress={onPress} style={[s.ib, wide && { paddingHorizontal: 12 }]}><Text style={s.ibTxt}>{label}</Text></Pressable>
);
const Brand = ({ h = 56 }) => (
  <Image source={require('./assets/logo-header.jpg')} style={{ height: h, width: h * (760 / 255) }} resizeMode="contain" />
);
function LogoImg({ uri, name }) {
  const [bad, setBad] = useState(false);
  if (!uri || bad) return <View style={[s.logo, s.logoFb]}><Text style={s.logoInit}>{name.slice(0, 1).toUpperCase()}</Text></View>;
  return <Image source={{ uri }} style={s.logo} resizeMode="contain" onError={() => setBad(true)} />;
}
const Row = React.memo(function Row({ c, fav, ok, cur, onPlay, onFav }) {
  return (
    <Pressable style={[s.row, cur && { backgroundColor: C.surface }]} onPress={() => onPlay(c)}>
      <LogoImg uri={c.logo} name={c.name} />
      <View style={{ flex: 1 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Text style={s.rname} numberOfLines={1}>{c.name}</Text>
          {ok ? <View style={s.okdot} /> : null}
        </View>
        <Text style={s.rgroup} numberOfLines={1}>{c.group}</Text>
      </View>
      {onFav ? (
        <Pressable hitSlop={12} onPress={() => onFav(c)}><Text style={[s.star, fav && { color: C.accent }]}>{fav ? '★' : '☆'}</Text></Pressable>
      ) : null}
    </Pressable>
  );
});
function HowTo() {
  return (
    <View>
      <Text style={s.h3a}>Comment l’utiliser</Text>
      {[
        'Touchez ☰ (menu en haut à gauche) pour changer de catégorie en un geste.',
        'Touchez une chaîne pour la regarder. Touchez l’étoile ☆ pour l’ajouter à vos favoris.',
        'Pincez l’image à deux doigts pour zoomer. Touchez deux fois pour remplir l’écran.',
        'Tournez le téléphone pour regarder en grand. Touchez ⏮ ⏭ pour changer de chaîne.',
        'Le bouton Retour du téléphone ferme le lecteur ou le menu.',
        'Un point vert ● signale une chaîne qui fonctionne. Si une chaîne ne marche pas, essayez-en une autre.',
      ].map((t, i) => <Text key={i} style={s.li}>{i + 1}. {t}</Text>)}
    </View>
  );
}
function Thanks() {
  return (
    <View style={s.thanks}>
      <Text style={s.thanksTxt}>
        Cette application est l’œuvre de <Text style={{ color: C.accent, fontWeight: '700' }}>{DEV_NAME}</Text>, son concepteur.
        Bravo pour ce travail et courage pour la suite ! 👏{'\n'}Vous pouvez l’encourager en partageant l’application autour de vous.{'\n'}
        <Text style={{ color: C.dim }}>Contact : </Text>
        <Text style={{ color: '#8fd0ff', fontWeight: '600' }} onPress={() => Linking.openURL('mailto:' + CONTACT_EMAIL)}>{CONTACT_EMAIL}</Text>
      </Text>
    </View>
  );
}
function SubBox({ onActivate }) {
  const [code, setCode] = useState('');
  const [msg, setMsg] = useState(null);
  return (
    <View>
      <Text style={s.step}>① Payer l’abonnement</Text>
      <Btn label="Payer mon abonnement" onPress={() => Linking.openURL(PAY_URL)} />
      <Text style={s.step}>② Recevoir votre code</Text>
      <Text style={s.p}>Après le paiement, envoyez votre preuve de paiement à {CONTACT_EMAIL} pour recevoir votre code d’activation.</Text>
      <Text style={s.step}>③ Entrer votre code</Text>
      <TextInput style={s.input} placeholder="XXXX-XXXX-XXXX" placeholderTextColor={C.dim} autoCapitalize="characters" autoCorrect={false} value={code} onChangeText={setCode} />
      <Btn label="Activer mon abonnement" onPress={async () => { setMsg(null); setMsg(await onActivate(code)); }} />
      {msg ? <Text style={[s.smsg, { color: msg.ok ? '#3ddc84' : '#ff8a95' }]}>{msg.text}</Text> : null}
    </View>
  );
}

/* ============================== LECTEUR NATIF ============================== */
function PlayerScreen({ ch, list, bad, okMap, active, onClose, onZap, onPlay, onCat, onOk, onBad, onRetry }) {
  const { width, height } = useWindowDimensions();
  const ins = useSafeAreaInsets();
  const land = width > height;
  const player = useVideoPlayer(ch.url, (p) => { p.play(); });
  const [status, setStatus] = useState('loading');
  const [playing, setPlaying] = useState(true);
  const [muted, setMuted] = useState(false);
  const [fit, setFit] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [ui, setUi] = useState(true);
  const pinch = useRef(null), lastTap = useRef(0), hideT = useRef(null);

  const showUi = useCallback(() => { setUi(true); clearTimeout(hideT.current); hideT.current = setTimeout(() => setUi(false), 3500); }, []);
  useEffect(() => { showUi(); return () => clearTimeout(hideT.current); }, []);
  useEffect(() => {
    try { activateKeepAwakeAsync('lm-player'); } catch (e) {}
    return () => { try { deactivateKeepAwake('lm-player'); } catch (e) {} };
  }, []);
  useEffect(() => {
    const a = player.addListener('statusChange', (e) => {
      setStatus(e.status);
      if (e.status === 'error') { onBad(ch); setUi(true); clearTimeout(hideT.current); }
    });
    const b = player.addListener('playingChange', (e) => {
      setPlaying(e.isPlaying);
      if (e.isPlaying) { setStatus('readyToPlay'); onOk(ch); showUi(); }
    });
    return () => { a.remove(); b.remove(); };
  }, [player]);
  useEffect(() => { try { player.muted = muted; } catch (e) {} }, [muted, player]);

  const clampZoom = (z) => Math.min(3, Math.max(1, Math.round(z * 100) / 100));
  const dist = (t) => Math.hypot(t[0].pageX - t[1].pageX, t[0].pageY - t[1].pageY);
  const onTap = () => {
    const n = Date.now();
    if (n - lastTap.current < 320) { setFit((f) => (f === 0 ? 1 : 0)); lastTap.current = 0; showUi(); return; }
    lastTap.current = n;
    if (ui) { clearTimeout(hideT.current); setUi(false); } else showUi();
  };
  const busy = status === 'loading' || status === 'idle';
  const rows = list.filter((c) => !bad[c.url] || c.url === ch.url).slice(0, 80);

  return (
    <Modal visible animationType="fade" onRequestClose={onClose} supportedOrientations={['portrait', 'landscape']} statusBarTranslucent>
      <View style={{ flex: 1, backgroundColor: '#000', paddingTop: land ? 0 : ins.top }}>
        <StatusBar hidden={land} style="light" />
        <View
          style={[s.vbox, land ? { flex: 1 } : { height: (width * 9) / 16 }]}
          onTouchStart={(e) => { const t = e.nativeEvent.touches; if (t.length === 2) pinch.current = { d: dist(t), z: zoom }; }}
          onTouchMove={(e) => { const t = e.nativeEvent.touches; if (pinch.current && t.length === 2) setZoom(clampZoom((pinch.current.z * dist(t)) / pinch.current.d)); }}
          onTouchEnd={(e) => { if (e.nativeEvent.touches.length < 2) pinch.current = null; }}
        >
          <View style={[StyleSheet.absoluteFill, { transform: [{ scale: zoom }] }]}>
            <VideoView player={player} style={StyleSheet.absoluteFill} contentFit={FITS[fit]} nativeControls={false} allowsFullscreen={false} allowsPictureInPicture surfaceType="textureView" />
          </View>
          <Pressable style={StyleSheet.absoluteFill} onPress={onTap} />
          {busy ? <View pointerEvents="none" style={s.center}><ActivityIndicator size="large" color={C.accent} /></View> : null}
          {status === 'error' ? (
            <View style={s.errBox}>
              <Text style={s.errTxt}>Cette chaîne ne répond pas. Elle est peut-être hors ligne ou payante. Essayez-en une autre.</Text>
              <View style={{ flexDirection: 'row', gap: 10 }}>
                <Btn label="Réessayer" onPress={onRetry} />
                <Btn label="Chaîne suivante ›" alt onPress={() => onZap(1)} />
              </View>
            </View>
          ) : null}
          {ui ? (
            <>
              <View style={s.ptop}>
                <IconBtn label="‹" onPress={onClose} />
                <Text style={s.ptitle} numberOfLines={1}>{ch.name}</Text>
                <IconBtn label="⏮" onPress={() => { onZap(-1); }} />
                <IconBtn label="⏭" onPress={() => { onZap(1); }} />
              </View>
              <View style={s.pbot}>
                <IconBtn label={playing ? '⏸' : '▶'} onPress={() => { playing ? player.pause() : player.play(); showUi(); }} />
                <IconBtn label={muted ? '🔇' : '🔊'} onPress={() => { setMuted((m) => !m); showUi(); }} />
                <IconBtn label={FIT_LABELS[fit]} wide onPress={() => { setFit((f) => (f + 1) % 3); showUi(); }} />
                <IconBtn label="−" onPress={() => { setZoom((z) => clampZoom(z - 0.25)); showUi(); }} />
                <IconBtn label={Math.round(zoom * 100) + '%'} wide onPress={() => { setZoom(1); showUi(); }} />
                <IconBtn label="+" onPress={() => { setZoom((z) => clampZoom(z + 0.25)); showUi(); }} />
              </View>
            </>
          ) : null}
        </View>
        {!land ? (
          <View style={{ flex: 1, backgroundColor: C.bg }}>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ flexGrow: 0 }} contentContainerStyle={s.chipsRow}>
              {CATEGORIES.map((c) => <Chip key={c.key} label={c.ico + ' ' + c.name} on={c.url === active} onPress={() => onCat(c)} />)}
            </ScrollView>
            <Text style={s.h3}>Autres chaînes</Text>
            <FlatList data={rows} keyExtractor={(c, i) => c.url + i} renderItem={({ item }) => <Row c={item} ok={!!okMap[item.url]} cur={item.url === ch.url} onPlay={onPlay} />} />
          </View>
        ) : null}
      </View>
    </Modal>
  );
}

/* ============================== APPLICATION ============================== */
export default function App() {
  return (<SafeAreaProvider><Main /></SafeAreaProvider>);
}

function Main() {
  const ins = useSafeAreaInsets();
  const [ready, setReady] = useState(false);
  const [tab, setTab] = useState('live');
  const [active, setActive] = useState(CATEGORIES[0].url);
  const [channels, setChannels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [favs, setFavs] = useState([]);
  const [recent, setRecent] = useState([]);
  const [okMap, setOkMap] = useState({});
  const [badMap, setBadMap] = useState({});
  const [hideBad, setHideBad] = useState(true);
  const [onlyOk, setOnlyOk] = useState(false);
  const [custom, setCustom] = useState([]);
  const [dev, setDev] = useState(false);
  const [adultOk, setAdultOk] = useState(false);
  const [welcomed, setWelcomed] = useState(true);
  const [welcome, setWelcome] = useState(false);
  const [drawer, setDrawer] = useState(false);
  const [query, setQuery] = useState('');
  const [current, setCurrent] = useState(null);
  const [playFrom, setPlayFrom] = useState('live');
  const [pkey, setPkey] = useState(0);
  const [lic, setLic] = useState(null);
  const [now, setNow] = useState(Date.now());
  const [toast, setToast] = useState('');
  const toastT = useRef(null), reqId = useRef(0), taps = useRef({ n: 0, t: 0 });

  const showToast = useCallback((m, ms = 2200) => { setToast(m); clearTimeout(toastT.current); toastT.current = setTimeout(() => setToast(''), ms); }, []);

  // ---- chargement des données enregistrées ----
  useEffect(() => {
    (async () => {
      const [a, f, r, o, b, h, c, d, ad, w, l] = await Promise.all([
        load('active', CATEGORIES[0].url), load('favs', []), load('recent', []), load('ok', {}), load('bad', {}),
        load('hideBad', true), load('custom', []), load('dev', false), load('adultOk', false), load('welcomed', false), load('lic', null),
      ]);
      let lc = l;
      if (!lc) { lc = { start: Date.now(), until: 0, last: Date.now(), used: [] }; save('lic', lc); }
      setActive(a); setFavs(f); setRecent(r); setOkMap(o); setBadMap(b); setHideBad(h); setCustom(c); setDev(d);
      setAdultOk(ad); setWelcomed(w); setLic(lc); setReady(true);
    })();
  }, []);
  useEffect(() => { const t = setInterval(() => setNow(Date.now()), 30000); return () => clearInterval(t); }, []);
  useEffect(() => { if (lic && now > lic.last) { const n = { ...lic, last: now }; setLic(n); save('lic', n); } }, [now]);

  const st = statusOf(lic, now);
  useEffect(() => { if (st.s === 'expired') { setCurrent(null); setDrawer(false); setWelcome(false); } }, [st.s]);
  useEffect(() => { if (ready && !welcomed && st.s !== 'expired' && st.s !== 'loading') setWelcome(true); }, [ready, welcomed, st.s]);

  // ---- playlists ----
  const loadPlaylist = useCallback(async (url) => {
    const id = ++reqId.current; setLoading(true); setError('');
    try { const list = await fetchPlaylist(url); if (id !== reqId.current) return; setChannels(list); }
    catch (e) { if (id !== reqId.current) return; setChannels([]); setError('Impossible de charger la playlist. Vérifiez votre connexion ou le lien.'); }
    if (id === reqId.current) setLoading(false);
  }, []);
  useEffect(() => { if (ready) loadPlaylist(active); }, [ready, active]);

  const select = (url) => { setActive(url); save('active', url); setTab('live'); };
  const pickCat = (cat) => {
    if (cat.adult && !adultOk) {
      Alert.alert('Contenu pour adultes', 'Cette catégorie est réservée aux personnes de 18 ans et plus. Avez-vous 18 ans ou plus ?', [
        { text: 'Non', style: 'cancel' },
        { text: 'Oui, j’ai 18 ans ou plus', onPress: () => { setAdultOk(true); save('adultOk', true); select(cat.url); } },
      ]);
      return;
    }
    select(cat.url);
  };

  // ---- favoris, récents, état des chaînes ----
  const toggleFav = (ch) => setFavs((f) => { const n = f.some((x) => x.url === ch.url) ? f.filter((x) => x.url !== ch.url) : [ch, ...f]; save('favs', n); return n; });
  const markOk = useCallback((ch) => {
    setOkMap((m) => { if (m[ch.url]) return m; const n = { ...m, [ch.url]: 1 }; save('ok', n); return n; });
    setBadMap((m) => { if (!m[ch.url]) return m; const n = { ...m }; delete n[ch.url]; save('bad', n); return n; });
    setRecent((r) => { const n = [ch, ...r.filter((x) => x.url !== ch.url)].slice(0, 20); save('recent', n); return n; });
  }, []);
  const markBad = useCallback((ch) => {
    setBadMap((m) => { const n = { ...m, [ch.url]: 1 }; save('bad', n); return n; });
    setOkMap((m) => { if (!m[ch.url]) return m; const n = { ...m }; delete n[ch.url]; save('ok', n); return n; });
  }, []);

  // ---- lecteur ----
  const playList = playFrom === 'favs' ? favs : playFrom === 'recent' ? recent : channels;
  const play = (ch) => { setPlayFrom(tab === 'favs' ? 'favs' : tab === 'recent' ? 'recent' : 'live'); setPkey((k) => k + 1); setCurrent(ch); };
  const switchTo = (ch) => { setPkey((k) => k + 1); setCurrent(ch); };
  const zap = (dir) => {
    const L = playList; if (!current || !L.length) return;
    let i = L.findIndex((c) => c.url === current.url);
    if (i < 0) i = dir > 0 ? -1 : 0;
    for (let k = 0; k < L.length; k++) {
      i = (i + dir + L.length) % L.length;
      const c = L[i];
      if (c.url !== current.url && !badMap[c.url]) { switchTo(c); showToast((dir > 0 ? '▶ ' : '◀ ') + c.name, 1600); return; }
    }
    showToast('Aucune autre chaîne disponible');
  };

  // ---- bouton Retour du téléphone (les fenêtres ouvertes gèrent le leur) ----
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (tab !== 'live') { setTab('live'); return true; }
      return false;
    });
    return () => sub.remove();
  }, [tab]);

  // ---- abonnement ----
  const activate = async (raw) => {
    const code = raw.toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (code.length !== 12) return { ok: false, text: 'Le code contient 12 lettres et chiffres.' };
    let h;
    try { h = await Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, SALT + code); }
    catch (e) { return { ok: false, text: 'Impossible de vérifier le code.' }; }
    if (!HASHES.includes(h)) return { ok: false, text: 'Code invalide. Vérifiez et réessayez.' };
    if (lic.used.includes(h)) return { ok: false, text: 'Ce code a déjà été utilisé sur cet appareil.' };
    const n = Math.max(Date.now(), lic.last);
    const next = { ...lic, used: [...lic.used, h], until: Math.max(n, lic.until) + SUB_DAYS * DAY, last: n };
    setLic(next); save('lic', next); setNow(Date.now());
    return { ok: true, text: 'Abonnement activé : ' + SUB_DAYS + ' jours. Merci !' };
  };
  const shareApp = () => Share.share({ message: 'Regardez la télé gratuitement avec Ledys Média — La voix qui élève.' }).catch(() => {});
  const closeWelcome = () => { setWelcome(false); setWelcomed(true); save('welcomed', true); };

  // ---- listes affichées ----
  const favSet = useMemo(() => new Set(favs.map((f) => f.url)), [favs]);
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    let d = tab === 'favs' ? favs : tab === 'recent' ? recent : channels;
    if (q) d = d.filter((c) => c.name.toLowerCase().includes(q));
    let hidden = 0;
    if (tab === 'live') {
      if (onlyOk) d = d.filter((c) => okMap[c.url]);
      else if (hideBad) { const n = d.length; d = d.filter((c) => !badMap[c.url]); hidden = n - d.length; }
    }
    return { d, hidden };
  }, [tab, favs, recent, channels, query, onlyOk, hideBad, okMap, badMap]);

  /* ---------- écrans de départ ---------- */
  if (!ready || !lic) return <View style={[s.root, s.center]}><ActivityIndicator color={C.accent} size="large" /></View>;
  if (st.s === 'expired') {
    return (
      <View style={[s.root, { paddingTop: ins.top }]}>
        <StatusBar style="light" />
        <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
          <Brand />
          <Text style={s.h2}>{lic.until ? 'Votre abonnement est terminé' : 'Votre essai gratuit de 3 jours est terminé'}</Text>
          <Text style={s.p}>Pour continuer à regarder la télé, activez votre abonnement.</Text>
          <SubBox onActivate={activate} />
        </ScrollView>
      </View>
    );
  }

  const resume = recent.length && !query.trim() && tab === 'live' ? recent[0] : null;
  const Head = (
    <View>
      {tab === 'live' ? (
        <>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ flexGrow: 0 }} contentContainerStyle={s.chipsRow}>
            {CATEGORIES.map((c) => <Chip key={c.key} label={c.ico + ' ' + c.name} on={c.url === active} onPress={() => pickCat(c)} />)}
          </ScrollView>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ flexGrow: 0 }} contentContainerStyle={[s.chipsRow, { paddingTop: 0 }]}>
            <Chip label="Masquer les chaînes en panne" on={hideBad && !onlyOk} onPress={() => { const v = !hideBad; setHideBad(v); setOnlyOk(false); save('hideBad', v); }} />
            <Chip label="● Seulement celles qui marchent" on={onlyOk} onPress={() => setOnlyOk((v) => !v)} />
          </ScrollView>
          {resume ? (
            <Pressable style={s.resume} onPress={() => play(resume)}>
              <Text style={{ color: C.accent, fontSize: 22 }}>▶</Text>
              <View><Text style={s.rgroup}>Reprendre</Text><Text style={s.rname}>{resume.name}</Text></View>
            </Pressable>
          ) : null}
          {filtered.hidden ? <Text style={s.hid}>{filtered.hidden} chaîne(s) en panne masquée(s)</Text> : null}
        </>
      ) : null}
    </View>
  );

  return (
    <View style={s.root}>
      <StatusBar style="light" />
      <View style={{ height: ins.top, backgroundColor: '#000' }} />
      <View style={s.header}>
        <Pressable style={s.hbtn} onPress={() => setDrawer(true)} accessibilityLabel="Menu"><Text style={s.hbtnTxt}>☰</Text></Pressable>
        <View style={{ flex: 1, alignItems: 'center' }}><Brand h={48} /></View>
        <Pressable style={s.hbtn} onPress={() => { showToast('Actualisation…', 1200); loadPlaylist(active); }} accessibilityLabel="Actualiser"><Text style={s.hbtnTxt}>↻</Text></Pressable>
      </View>
      {st.s === 'trial' ? (
        <Pressable style={s.sub} onPress={() => setTab('set')}><Text style={s.subTxt}>Essai gratuit : il reste <Text style={{ color: C.accent, fontWeight: '700' }}>{fmtLeft(st.left)}</Text> · S’abonner ›</Text></Pressable>
      ) : st.s === 'active' ? (
        <View style={s.sub}><Text style={s.subTxt}>Abonnement actif : <Text style={{ color: C.accent, fontWeight: '700' }}>{fmtLeft(st.left)}</Text> restants</Text></View>
      ) : null}

      <View style={{ flex: 1 }}>
        {tab !== 'set' ? (
          <TextInput style={s.search} placeholder="Rechercher une chaîne" placeholderTextColor={C.dim} value={query} onChangeText={setQuery} autoCorrect={false} />
        ) : null}
        {tab === 'live' && loading ? (
          <View style={s.center}><ActivityIndicator color={C.accent} size="large" /><Text style={[s.p, { marginTop: 12 }]}>Chargement des chaînes…</Text></View>
        ) : tab === 'live' && error ? (
          <View style={s.center}><Text style={s.p}>{error}</Text><Btn label="Réessayer" onPress={() => loadPlaylist(active)} style={{ marginTop: 14 }} /></View>
        ) : tab === 'set' ? (
          <SettingsView
            st={st} onActivate={activate} okN={Object.keys(okMap).length} badN={Object.keys(badMap).length}
            onReset={() => { setOkMap({}); setBadMap({}); save('ok', {}); save('bad', {}); showToast('Tests réinitialisés'); }}
            onShare={shareApp} onHow={() => setWelcome(true)} dev={dev} custom={custom} count={channels.length}
            onVersionTap={() => {
              const n = Date.now(); const t = taps.current; t.n = n - t.t < 2500 ? t.n + 1 : 1; t.t = n;
              if (t.n >= 7) { t.n = 0; const v = !dev; setDev(v); save('dev', v); showToast(v ? 'Mode concepteur activé' : 'Mode concepteur désactivé'); }
            }}
            onAdd={(name, url) => { const n = [...custom, { name, url }]; setCustom(n); save('custom', n); select(url); }}
            onRemove={(url) => { const n = custom.filter((c) => c.url !== url); setCustom(n); save('custom', n); if (active === url) select(CATEGORIES[0].url); }}
            onSelect={select}
          />
        ) : (
          <FlatList
            data={filtered.d}
            keyExtractor={(c, i) => c.url + i}
            initialNumToRender={16}
            windowSize={9}
            ListHeaderComponent={Head}
            ListEmptyComponent={<Text style={s.empty}>{tab === 'favs' ? 'Touchez l’étoile d’une chaîne pour la retrouver ici.' : tab === 'recent' ? 'Les chaînes que vous regardez apparaîtront ici.' : onlyOk ? 'Aucune chaîne testée pour l’instant. Ouvrez des chaînes : celles qui fonctionnent seront marquées d’un point vert.' : 'Aucune chaîne trouvée.'}</Text>}
            renderItem={({ item }) => <Row c={item} fav={favSet.has(item.url)} ok={!!okMap[item.url]} onPlay={play} onFav={toggleFav} />}
          />
        )}
      </View>

      <View style={[s.tabs, { paddingBottom: ins.bottom }]}>
        {[['live', 'Chaînes'], ['favs', 'Favoris'], ['recent', 'Récents'], ['set', 'Réglages']].map(([k, label]) => (
          <Pressable key={k} style={s.tab} onPress={() => setTab(k)}>
            <Text style={[s.tabTxt, tab === k && s.tabOn]}>{label}</Text>
            {tab === k ? <View style={s.tabDot} /> : null}
          </Pressable>
        ))}
      </View>

      {/* menu latéral */}
      <Modal visible={drawer} transparent animationType="fade" onRequestClose={() => setDrawer(false)}>
        <View style={{ flex: 1, flexDirection: 'row' }}>
          <View style={[s.dpanel, { paddingTop: ins.top + 8 }]}>
            <ScrollView>
              <View style={s.dhead}><Brand h={50} /></View>
              <Text style={s.dsec}>Catégories</Text>
              {CATEGORIES.map((c) => <DItem key={c.key} ico={c.ico} label={c.name} on={tab === 'live' && active === c.url} onPress={() => { setDrawer(false); pickCat(c); }} />)}
              <Text style={s.dsec}>Pays et langues</Text>
              {PRESETS.map((p) => <DItem key={p.url} ico={p.ico} label={p.name} on={tab === 'live' && active === p.url} onPress={() => { setDrawer(false); select(p.url); }} />)}
              {dev && custom.length ? <Text style={s.dsec}>Mes playlists</Text> : null}
              {dev ? custom.map((p) => <DItem key={p.url} ico="📄" label={p.name} on={tab === 'live' && active === p.url} onPress={() => { setDrawer(false); select(p.url); }} />) : null}
              <Text style={s.dsec}>Mes chaînes</Text>
              <DItem ico="★" label="Favoris" extra={String(favs.length)} on={tab === 'favs'} onPress={() => { setDrawer(false); setTab('favs'); }} />
              <DItem ico="🕘" label="Récents" on={tab === 'recent'} onPress={() => { setDrawer(false); setTab('recent'); }} />
              <Text style={s.dsec}>Plus</Text>
              <DItem ico="⚙️" label={STORE_BUILD ? 'Réglages' : 'Réglages et abonnement'} on={tab === 'set'} onPress={() => { setDrawer(false); setTab('set'); }} />
              <DItem ico="❓" label="Mode d’emploi" onPress={() => { setDrawer(false); setWelcome(true); }} />
              <DItem ico="🔗" label="Partager l’application" onPress={() => { setDrawer(false); shareApp(); }} />
            </ScrollView>
          </View>
          <Pressable style={{ flex: 1, backgroundColor: 'rgba(0,0,0,.6)' }} onPress={() => setDrawer(false)} />
        </View>
      </Modal>

      {/* bienvenue */}
      <Modal visible={welcome} transparent animationType="slide" onRequestClose={closeWelcome}>
        <View style={s.wback}>
          <View style={s.wcard}>
            <ScrollView>
              <Brand />
              <Text style={s.h2}>Bienvenue sur Ledys Média</Text>
              <Text style={s.p}>La voix qui élève.</Text>
              <HowTo />
              <Thanks />
              <Btn label="Commencer" onPress={closeWelcome} style={{ marginTop: 16 }} />
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* lecteur natif */}
      {current ? (
        <PlayerScreen
          key={pkey} ch={current} list={playList} bad={badMap} okMap={okMap} active={active}
          onClose={() => setCurrent(null)} onZap={zap} onPlay={switchTo}
          onCat={(c) => { setPlayFrom('live'); pickCat(c); }}
          onOk={markOk} onBad={markBad} onRetry={() => setPkey((k) => k + 1)}
        />
      ) : null}

      {toast ? <View pointerEvents="none" style={s.toast}><Text style={s.toastTxt}>{toast}</Text></View> : null}
    </View>
  );
}

const DItem = ({ ico, label, on, onPress, extra }) => (
  <Pressable style={[s.ditem, on && s.ditemOn]} onPress={onPress}>
    <Text style={s.dico}>{ico}</Text>
    <Text style={[s.dlab, on && { color: C.accent, fontWeight: '700' }]}>{label}</Text>
    {extra ? <Text style={s.dcount}>{extra}</Text> : null}
  </Pressable>
);

function SettingsView({ st, onActivate, okN, badN, onReset, onShare, onHow, dev, custom, count, onVersionTap, onAdd, onRemove, onSelect }) {
  const [name, setName] = useState(''); const [url, setUrl] = useState('');
  const valid = /^https?:\/\/\S+/i.test(url.trim());
  return (
    <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40 }} keyboardShouldPersistTaps="handled">
      {!STORE_BUILD ? (
        <View>
          <Text style={s.h2}>Abonnement</Text>
          <Text style={s.p}>{st.s === 'trial' ? 'Essai gratuit : il reste ' + fmtLeft(st.left) : st.s === 'active' ? 'Abonnement actif : ' + fmtLeft(st.left) + ' restants' : ''}</Text>
          <SubBox onActivate={onActivate} />
        </View>
      ) : null}
      {dev ? (
        <View>
          <Text style={s.h2}>Mes playlists</Text>
          <Text style={s.p}>{count} chaînes chargées</Text>
          {PRESETS.concat(custom.map((c) => ({ ...c, custom: true }))).map((p) => (
            <Pressable key={p.url} style={s.pl} onPress={() => onSelect(p.url)}>
              <View style={{ flex: 1 }}><Text style={s.rname}>{p.name}</Text><Text style={s.rgroup} numberOfLines={1}>{p.url}</Text></View>
              {p.custom ? <Text style={{ color: '#ff6b7d', fontWeight: '600' }} onPress={() => onRemove(p.url)}>Supprimer</Text> : null}
            </Pressable>
          ))}
          <Text style={s.h2}>Ajouter une playlist</Text>
          <TextInput style={s.input} placeholder="Nom (facultatif)" placeholderTextColor={C.dim} value={name} onChangeText={setName} />
          <TextInput style={s.input} placeholder="Lien M3U (https://…)" placeholderTextColor={C.dim} value={url} onChangeText={setUrl} autoCapitalize="none" autoCorrect={false} keyboardType="url" />
          <Btn label="Ajouter la playlist" disabled={!valid} onPress={() => { onAdd(name.trim() || 'Ma playlist', url.trim()); setName(''); setUrl(''); }} />
        </View>
      ) : null}
      <Text style={s.h2}>Tests des chaînes</Text>
      <Btn label={'Réinitialiser les tests (' + okN + ' OK, ' + badN + ' en panne)'} onPress={onReset} />
      <Text style={s.h2}>À propos</Text>
      <HowTo />
      <Thanks />
      <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
        <Btn label="Partager l’application" onPress={onShare} style={{ flex: 1 }} />
        <Btn label="Mode d’emploi" alt onPress={onHow} style={{ flex: 1 }} />
      </View>
      <Pressable onPress={onVersionTap}><Text style={s.ver}>Ledys Média · version 3{dev ? ' · mode concepteur' : ''}</Text></Pressable>
    </ScrollView>
  );
}

/* ============================== STYLES ============================== */
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 },
  header: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 12, paddingVertical: 6, backgroundColor: '#000' },
  hbtn: { width: 44, height: 44, borderRadius: 12, backgroundColor: C.surface, alignItems: 'center', justifyContent: 'center' },
  hbtnTxt: { color: C.text, fontSize: 22 },
  sub: { marginHorizontal: 12, marginTop: 8, padding: 10, borderRadius: 10, backgroundColor: C.surface },
  subTxt: { color: C.dim, fontSize: 13 },
  search: { margin: 12, marginBottom: 6, paddingHorizontal: 14, paddingVertical: 11, borderRadius: 12, backgroundColor: C.surface, color: C.text, fontSize: 16 },
  chipsRow: { paddingHorizontal: 12, paddingVertical: 8, gap: 8 },
  chip: { paddingHorizontal: 16, paddingVertical: 9, borderRadius: 22, backgroundColor: C.surface },
  chipOn: { backgroundColor: C.accent },
  chipTxt: { color: C.text, fontSize: 14, fontWeight: '600' },
  chipTxtOn: { color: C.bg },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 16, height: 72, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: C.line },
  logo: { width: 48, height: 48, borderRadius: 8, backgroundColor: '#fff' },
  logoFb: { backgroundColor: C.line, alignItems: 'center', justifyContent: 'center' },
  logoInit: { color: C.accent, fontSize: 20, fontWeight: '700' },
  rname: { color: C.text, fontSize: 16, fontWeight: '600', flexShrink: 1 },
  rgroup: { color: C.dim, fontSize: 13, marginTop: 2 },
  okdot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#3ddc84', marginLeft: 8 },
  star: { color: C.dim, fontSize: 28 },
  resume: { flexDirection: 'row', alignItems: 'center', gap: 14, marginHorizontal: 12, marginBottom: 6, padding: 12, borderRadius: 14, backgroundColor: C.surface },
  hid: { color: C.dim, fontSize: 13, textAlign: 'center', padding: 8 },
  empty: { color: C.dim, textAlign: 'center', marginTop: 40, paddingHorizontal: 32, fontSize: 15, lineHeight: 22 },
  tabs: { flexDirection: 'row', backgroundColor: C.surface, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: C.line },
  tab: { flex: 1, alignItems: 'center', paddingVertical: 13, gap: 4 },
  tabTxt: { color: C.dim, fontSize: 14 },
  tabOn: { color: C.accent, fontWeight: '700' },
  tabDot: { width: 5, height: 5, borderRadius: 3, backgroundColor: C.red },
  btn: { backgroundColor: C.accent, paddingHorizontal: 20, paddingVertical: 13, borderRadius: 12, alignItems: 'center' },
  btnAlt: { backgroundColor: C.surface },
  btnTxt: { color: C.bg, fontSize: 16, fontWeight: '700' },
  input: { backgroundColor: C.surface, color: C.text, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12, fontSize: 17, marginVertical: 6 },
  h2: { color: C.text, fontSize: 22, fontWeight: '800', marginTop: 20, marginBottom: 6 },
  h3: { color: C.dim, fontSize: 15, fontWeight: '600', paddingHorizontal: 16, paddingTop: 6, paddingBottom: 4 },
  h3a: { color: C.accent, fontSize: 16, fontWeight: '700', marginTop: 16, marginBottom: 6 },
  p: { color: C.dim, fontSize: 15, lineHeight: 22, marginVertical: 4 },
  li: { color: C.text, fontSize: 15, lineHeight: 23, marginVertical: 3 },
  step: { color: C.text, fontSize: 16, fontWeight: '700', marginTop: 16, marginBottom: 6 },
  smsg: { fontSize: 14, marginTop: 8 },
  thanks: { marginTop: 14, padding: 14, borderRadius: 14, backgroundColor: C.surface, borderLeftWidth: 4, borderLeftColor: C.accent },
  thanksTxt: { color: C.text, fontSize: 15, lineHeight: 23 },
  pl: { flexDirection: 'row', alignItems: 'center', padding: 14, borderRadius: 12, backgroundColor: C.surface, marginVertical: 5 },
  ver: { color: C.dim, textAlign: 'center', marginTop: 24, fontSize: 13 },
  toast: { position: 'absolute', bottom: 100, alignSelf: 'center', backgroundColor: '#222', paddingHorizontal: 18, paddingVertical: 11, borderRadius: 22, maxWidth: '88%' },
  toastTxt: { color: '#fff', fontSize: 14, textAlign: 'center' },
  dpanel: { width: '82%', maxWidth: 340, backgroundColor: C.bg },
  dhead: { paddingHorizontal: 16, paddingBottom: 10, borderBottomWidth: 1, borderBottomColor: C.line, backgroundColor: '#000' },
  dsec: { color: C.dim, fontSize: 12, fontWeight: '700', letterSpacing: 0.8, textTransform: 'uppercase', paddingHorizontal: 20, paddingTop: 16, paddingBottom: 6 },
  ditem: { flexDirection: 'row', alignItems: 'center', gap: 14, paddingHorizontal: 20, paddingVertical: 13 },
  ditemOn: { backgroundColor: C.surface },
  dico: { width: 26, textAlign: 'center', fontSize: 20, color: C.text },
  dlab: { flex: 1, color: C.text, fontSize: 16 },
  dcount: { color: C.dim, backgroundColor: C.line, borderRadius: 10, paddingHorizontal: 9, paddingVertical: 2, fontSize: 13, overflow: 'hidden' },
  wback: { flex: 1, backgroundColor: 'rgba(0,0,0,.78)', justifyContent: 'flex-end' },
  wcard: { backgroundColor: C.bg, borderTopLeftRadius: 22, borderTopRightRadius: 22, padding: 20, maxHeight: '92%' },
  vbox: { backgroundColor: '#000', overflow: 'hidden' },
  ptop: { position: 'absolute', top: 0, left: 0, right: 0, flexDirection: 'row', alignItems: 'center', gap: 8, padding: 8, backgroundColor: 'rgba(0,0,0,.55)' },
  pbot: { position: 'absolute', bottom: 0, left: 0, right: 0, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 8, backgroundColor: 'rgba(0,0,0,.55)' },
  ptitle: { flex: 1, color: '#fff', fontSize: 16, fontWeight: '600' },
  ib: { minWidth: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(255,255,255,.16)', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 8 },
  ibTxt: { color: '#fff', fontSize: 15, fontWeight: '600' },
  errBox: { ...StyleSheet.absoluteFillObject, backgroundColor: '#0c0c0c', alignItems: 'center', justifyContent: 'center', gap: 14, padding: 20 },
  errTxt: { color: '#fff', textAlign: 'center', fontSize: 15, lineHeight: 22 },
});
